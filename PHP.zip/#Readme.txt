change all database Info on php!

1. DB.php
2. key/auth.php