<?php
if(strpos($_SERVER['REQUEST_URI'],"DB.php")){
    require_once 'Utils.php';
    PlainDie();
}

$conn = new mysqli("fdb32.awardspace.net", "4135403_name", "5jn7OA:/307;fhx*", "4135403_name");
if($conn->connect_error != null){
    die($conn->connect_error);
}