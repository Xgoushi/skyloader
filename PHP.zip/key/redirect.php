<?php
    session_start();
    $_SESSION['signup']="plexus"; 
    header("Location: free_key.php");
?>