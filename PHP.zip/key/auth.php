<?php 

$dbhost = 'fdb32.awardspace.net';
$dbuser = '4135403_name';
$dbpass = '5jn7OA:/307;fhx*';
$db = '4135403_name';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass , $db) or die($conn); 

date_default_timezone_set('Asia/Jakarta');

if (mysqli_connect_error()){
	echo "Koneksi database gagal :". mysqli_connect_error();
}

?>