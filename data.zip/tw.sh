Gxghost=com.rekoo.pubgm;
eval `pm dump $Gxghost | grep LibraryDir`;
l=$legacyNativeLibraryDir;
arm=$(ls $l | grep arm);
lib=$l/$arm;
rm -rf $lib/{libCrashSight.so,libtgpa.so,libtool-checker.so,libflutter_qapm.so};
su -c am start -n $Gxghost/com.epicgames.ue4.SplashActivity;
sleep 4
/system/bin/iptables -A OUTPUT -s dl.listdl.com -j DROP
/system/bin/iptables -A OUTPUT -s lobby.igamecj.com -j DROP
echo "@Gxghost"








