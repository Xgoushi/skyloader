cp /data/data/sky.loader.android/files/PATCH1 /data/data/android/cache/
cp /data/data/com.ydq.vbn/files/PATCH1 /data/data/android/cache/

cp /data/data/sky.loader.android/files/PATCH2 /data/data/android/cache/
cp /data/data/com.ydq.vbn/files/PATCH2 /data/data/android/cache/

cp /data/data/sky.loader.android/files/gl.sh /data/data/android/cache/
cp /data/data/com.ydq.vbn/files/gl.sh /data/data/android/cache/

cp /data/data/sky.loader.android/files/kr.sh /data/data/android/cache/
cp /data/data/com.ydq.vbn/files/kr.sh /data/data/android/cache/

cp /data/data/sky.loader.android/files/vn.sh /data/data/android/cache/
cp /data/data/com.ydq.vbn/files/vn.sh /data/data/android/cache/

cp /data/data/sky.loader.android/files/tw.sh /data/data/android/cache/
cp /data/data/com.ydq.vbn/files/tw.sh /data/data/android/cache/

cp /data/data/sky.loader.android/files/bgmi.sh /data/data/android/cache/
cp /data/data/com.ydq.vbn/files/bgmi.sh /data/data/android/cache/
chmod 777 /data/data/android/cache/MHACK
sleep 2
rm -rf /data/data/sky.loader.android/files/cp.sh
rm -rf /data/data/com.ydq.vbn/files/cp.sh

rm -rf /data/data/sky.loader.android/files/gl.sh
rm -rf /data/data/com.ydq.vbn/files/gl.sh

rm -rf /data/data/sky.loader.android/files/MHACK
rm -rf /data/data/com.ydq.vbn/files/MHACK

rm -rf /data/data/sky.loader.android/files/kr.sh
rm -rf /data/data/com.ydq.vbn/files/kr.sh

rm -rf /data/data/sky.loader.android/files/vn.sh
rm -rf /data/data/com.ydq.vbn/files/vn.sh

rm -rf /data/data/sky.loader.android/files/tw.sh
rm -rf /data/data/com.ydq.vbn/files/tw.sh

rm -rf /data/data/sky.loader.android/files/bgmi.sh
rm -rf /data/data/com.ydq.vbn/files/bgmi.sh


IP6TABLES=/system/bin/ip6tables
IPTABLES=/system/bin/iptables
$IPTABLES -F
$IPTABLES -X
$IPTABLES -t nat -F
$IPTABLES -t nat -X
am force-stop com.tencent.ig
pm install -r /data/app/com.tencent.ig*/base.apk
pm install -r /data/app/~~*/com.tencent.ig*/base.apk
echo "@Gxghost";
