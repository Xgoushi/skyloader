Gxghost=com.tencent.ig;
lib=$(pm path $Gxghost | cut -d ':' -f2 | sed 's/\/base.apk//g')/lib/arm64;
rm -rf $lib/{libapp.so,libc++_shared.so,libflutter.so,libgamemaster.so,libgcloudarch.so,libhelpshiftlistener.so,libigshare.so,libImSDK.so,libkk-image.so,liblbs.so,libmarsxlog.so,libmmkv.so,libnpps-jni.so,libsentry.so,libsentry-android.so,libsoundtouch.so,libst-engine.so,libtgpa.so,libflutter_qapm.so,libtool-checker.so} > /dev/null 2>&1
rm -rf /data/media/0/Android/data/$Gxghost/files/{hawk_data,TGPA,log}
rm -rf /data/media/0/Android/data/$Gxghost/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_puffer*,puffer_temp}
rm -rf /data/data/$Gxghost/{app_bugly,app_crashrecord,app_crashSight}; 
touch /data/data/$Gxghost/{app_bugly,app_crashrecord,app_crashSight}; 
chmod 4000 /data/data/$Gxghost/{app_bugly,app_crashrecord,app_crashSight}; 
rm -rf /data/data/$Gxghost/files; 
chmod -R 000 /data/data/$Gxghost/files;
pm disable $Gxghost/com.sirius.flutter.im.MeemoBGService  &>/dev/null; 
pm disable $Gxghost/com.tencent.midas.oversea.newnetwork.service.APNetDetectService  &>/dev/null; 
pm disable $Gxghost/com.sirius.meemo.foreground_service.ForegroundService &>/dev/null; 
Gxghost1=/system/bin/ip6tables;
Gxghost2=/system/bin/$iptables;
Gxghost1 -I OUTPUT -p tcp -m string --string "cloud.gsdk.proximabeta.com" --algo bm -j DROP
Gxghost1 -I INPUT -p tcp -m string --string "cloud.gsdk.proximabeta.com" --algo bm -j DROP
Gxghost1 -I OUTPUT -p tcp -m string --string "oth.eve.mdt.qq.com" --algo bm -j DROP
Gxghost1 -I INPUT -p tcp -m string --string "oth.eve.mdt.qq.com" --algo bm -j DROP
Gxghost1 -I OUTPUT -p tcp -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP
Gxghost1 -I INPUT -p tcp -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP
Gxghost1 -I OUTPUT -p tcp -m string --string "lobby.igamecj.com" --algo bm -j DROP
Gxghost1 -I INPUT -p tcp -m string --string "lobby.igamecj.com" --algo bm -j DROP
Gxghost1 -I OUTPUT -p tcp -m string --string "android.crashsight.wetest.net" --algo bm -j DROP
Gxghost1 -I INPUT -p tcp -m string --string "android.crashsight.wetest.net" --algo bm -j DROP
Gxghost1 -I OUTPUT -p tcp -m string --string "cloud.vmp.onezapp.com" --algo bm -j DROP
Gxghost1 -I INPUT -p tcp -m string --string "cloud.vmp.onezapp.com" --algo bm -j DROP
Gxghost1 -I OUTPUT -p tcp -m string --string "dl.listdl.com" --algo bm -j DROP
Gxghost1 -I INPUT -p tcp -m string --string "dl.listdl.com" --algo bm -j DROP
Gxghost2 -I OUTPUT -p tcp -m string --string "cloud.gsdk.proximabeta.com" --algo bm -j DROP
Gxghost2 -I INPUT -p tcp -m string --string "cloud.gsdk.proximabeta.com" --algo bm -j DROP
Gxghost2 -I OUTPUT -p tcp -m string --string "oth.eve.mdt.qq.com" --algo bm -j DROP
Gxghost2 -I INPUT -p tcp -m string --string "oth.eve.mdt.qq.com" --algo bm -j DROP
Gxghost2 -I OUTPUT -p tcp -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP
Gxghost2 -I INPUT -p tcp -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP
Gxghost2 -I OUTPUT -p tcp -m string --string "lobby.igamecj.com" --algo bm -j DROP
Gxghost2 -I INPUT -p tcp -m string --string "lobby.igamecj.com" --algo bm -j DROP
Gxghost2 -I OUTPUT -p tcp -m string --string "android.crashsight.wetest.net" --algo bm -j DROP
Gxghost2 -I INPUT -p tcp -m string --string "android.crashsight.wetest.net" --algo bm -j DROP
Gxghost2 -I OUTPUT -p tcp -m string --string "cloud.vmp.onezapp.com" --algo bm -j DROP
Gxghost2 -I INPUT -p tcp -m string --string "cloud.vmp.onezapp.com" --algo bm -j DROP
Gxghost2 -I OUTPUT -p tcp -m string --string "dl.listdl.com" --algo bm -j DROP
Gxghost2 -I INPUT -p tcp -m string --string "dl.listdl.com" --algo bm -j DROP
su -c am start -n $Gxghost/com.epicgames.ue4.SplashActivity;
sleep 4
chmod 000 $lib/libgcloud.so;
chmod 000 $lib/libanogs.so;
chmod 000 $lib/libUE4.so;
chmod 000 $lib/libCrashSight.so;
sleep 11
chmod 775 $lib/libgcloud.so;
chmod 775 $lib/libanogs.so;
chmod 775 $lib/libUE4.so;
chmod 775 $lib/libCrashSight.so;
echo "@Gxghost";

