echo "start"
GAME=com.pubg.imobile

am force-stop com.tencent.ig
am force-stop com.pubg.krmobile
am force-stop com.rekoo.pubgm
am force-stop com.vng.pubgmobile
pkill com.tencent.ig
pkill com.pubg.krmobile
pkill com.rekoo.pubgm
pkill com.vng.pubgmobile


am start -S -W $GAME/com.epicgames.ue4.SplashActivity &> /dev/null
sleep 2.5
su -c /data/data/android/cache/not ON_LOGO 
while [ ! -e /sdcard/Android/data/$GAME/files/TGPA ]; do sleep 0.1; done
chmod 000 $lib/libUE4.so
echo "done"